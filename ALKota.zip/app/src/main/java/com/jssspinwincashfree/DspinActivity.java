package com.jssspinwincashfree;

import android.animation.*;
import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.anupkumarpanwar.scratchview.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.unity3d.ads.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.jetbrains.kotlin.*;
import org.json.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdValue;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.OnAdMetadataChangedListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import android.widget.LinearLayout.LayoutParams;
import androidx.annotation.Nullable;

public class DspinActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	RewardedAd TechnoSahilIA;
	private double num = 0;
	private double count = 0;
	private double balance = 0;
	private HashMap<String, Object> v = new HashMap<>();
	private String transKey = "";
	private HashMap<String, Object> m = new HashMap<>();
	private HashMap<String, Object> map = new HashMap<>();
	private double coi = 0;
	private String color1 = "";
	private String color2 = "";
	private String ripple = "";
	private String strokeclr = "";
	private double stroke = 0;
	private double radius = 0;
	private double elevation = 0;
	private double totalBalance = 0;
	
	private ArrayList<Double> spin_list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout top;
	private LinearLayout linear4;
	private LinearLayout Banner_Ads2;
	private LinearLayout linear5;
	private LinearLayout linear7;
	private LinearLayout linear_top;
	private ImageView imageview_top;
	private TextView textview1;
	private LinearLayout lin_coins;
	private ImageView imageview18;
	private TextView coin_balance;
	private ImageView imageview_Spin;
	private ImageView imageview16;
	private LinearLayout Time_Spin;
	private TextView Spin;
	private TextView Time;
	private LinearLayout Banner_Ads;
	
	private SharedPreferences sp;
	private Calendar cal = Calendar.getInstance();
	private ObjectAnimator obj = new ObjectAnimator();
	private TimerTask timer;
	private SharedPreferences sp_spin;
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private Intent i_net = new Intent();
	private Calendar c = Calendar.getInstance();
	private DatabaseReference All_Users = _firebase.getReference("All_Users");
	private ChildEventListener _All_Users_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference history = _firebase.getReference("history");
	private ChildEventListener _history_child_listener;
	private AlertDialog.Builder di;
	private AlertDialog.Builder d;
	private SharedPreferences data;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.dspin);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		top = findViewById(R.id.top);
		linear4 = findViewById(R.id.linear4);
		Banner_Ads2 = findViewById(R.id.Banner_Ads2);
		linear5 = findViewById(R.id.linear5);
		linear7 = findViewById(R.id.linear7);
		linear_top = findViewById(R.id.linear_top);
		imageview_top = findViewById(R.id.imageview_top);
		textview1 = findViewById(R.id.textview1);
		lin_coins = findViewById(R.id.lin_coins);
		imageview18 = findViewById(R.id.imageview18);
		coin_balance = findViewById(R.id.coin_balance);
		imageview_Spin = findViewById(R.id.imageview_Spin);
		imageview16 = findViewById(R.id.imageview16);
		Time_Spin = findViewById(R.id.Time_Spin);
		Spin = findViewById(R.id.Spin);
		Time = findViewById(R.id.Time);
		Banner_Ads = findViewById(R.id.Banner_Ads);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		sp_spin = getSharedPreferences("sp_spin", Activity.MODE_PRIVATE);
		net = new RequestNetwork(this);
		auth = FirebaseAuth.getInstance();
		di = new AlertDialog.Builder(this);
		d = new AlertDialog.Builder(this);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		imageview_top.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i_net.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(i_net);
			}
		});
		
		Spin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (sp_spin.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "").equals("50")) {
					_MaterialDialog("Completed", "You have already completed daily 50 spin.", "HIDE", "OK");
				}
				else {
					UnityAds.show(DspinActivity.this, "Rewarded_Android", new UnityAdsShowOptions(), showListener);
					SketchwareUtil.showMessage(getApplicationContext(), "Loading...");
				}
			}
		});
		
		obj.addListener(new Animator.AnimatorListener() {
			@Override
			public void onAnimationStart(Animator _param1) {
				Spin.setEnabled(false);
			}
			
			@Override
			public void onAnimationEnd(Animator _param1) {
				Spin.setEnabled(false);
				Spin.setVisibility(View.GONE);
				Time.setVisibility(View.VISIBLE);
				count = 25;
				Time.setText("00:".concat(String.valueOf((long)(count))));
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								count--;
								Time.setText("00:".concat(String.valueOf((long)(count))));
								if (count == 0) {
									timer.cancel();
									Spin.setEnabled(true);
									Spin.setVisibility(View.VISIBLE);
									Time.setVisibility(View.GONE);
								}
							}
						});
					}
				};
				_timer.scheduleAtFixedRate(timer, (int)(1000), (int)(1000));
				if (num == 0) {
					_RewardsDialog("Congratulations", "You have won ", 10, " Coins");
				}
				if (num == 1) {
					_RewardsDialog("Congratulations", "You have won ", 1, " Coins");
				}
				if (num == 2) {
					_RewardsDialog("Congratulations", "You have won ", 2, " Coins");
				}
				if (num == 3) {
					_RewardsDialog("Congratulations", "You have won ", 3, " Coins");
				}
				if (num == 4) {
					_RewardsDialog("Congratulations", "You have won ", 4, " Coins");
				}
				if (num == 5) {
					_RewardsDialog("Congratulations", "You have won ", 5, " Coins");
				}
				if (num == 6) {
					_RewardsDialog("Congratulations", "You have won ", 6, " Coins");
				}
				if (num == 7) {
					_RewardsDialog("Congratulations", "You have won ", 7, " Coins");
				}
				if (num == 8) {
					_RewardsDialog("Congratulations", "You have won ", 8, " Coins");
				}
				if (num == 9) {
					_RewardsDialog("Congratulations", "You have won ", 9, " Coins");
				}
			}
			
			@Override
			public void onAnimationCancel(Animator _param1) {
				
			}
			
			@Override
			public void onAnimationRepeat(Animator _param1) {
				
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				i_net.setClass(getApplicationContext(), NetworkActivity.class);
				i_net.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i_net);
			}
		};
		
		_All_Users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("balance")) {
						coin_balance.setText(_childValue.get("balance").toString().concat(" Coins"));
						balance = Double.parseDouble(_childValue.get("balance").toString());
					}
					if (_childValue.containsKey("total balance")) {
						totalBalance = Double.parseDouble(_childValue.get("total balance").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		All_Users.addChildEventListener(_All_Users_child_listener);
		
		_history_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		history.addChildEventListener(_history_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_NavStatusBarColor("#171E2E", "#0F131E");
		net.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "Aaja_kumar", _net_request_listener);
		Time.setVisibility(View.GONE);
		_Home_Degin();
		totalBalance = 0;
		_loadRewared();
		AdView Banner_Ads_adView = new AdView(DspinActivity.this);
		
		Banner_Ads_adView.setAdSize(AdSize.BANNER);
		        Banner_Ads_adView.setAdUnitId(data.getString("admobBanner", ""));
		        Banner_Ads.addView(Banner_Ads_adView);
		        
		        AdRequest Banner_Ads_req = new            AdRequest.Builder().build();
		   Banner_Ads_adView.loadAd(Banner_Ads_req);
		AdView Banner_Ads2_adView = new AdView(DspinActivity.this);
		
		Banner_Ads2_adView.setAdSize(AdSize.BANNER);
		        Banner_Ads2_adView.setAdUnitId(data.getString("admobBanner", ""));
		        Banner_Ads2.addView(Banner_Ads2_adView);
		        
		        AdRequest Banner_Ads2_req = new            AdRequest.Builder().build();
		   Banner_Ads2_adView.loadAd(Banner_Ads2_req);
		UnityAds.initialize(getApplicationContext(), data.getString("unityID", ""), false, new IUnityAdsInitializationListener() {
			@Override
			public void onInitializationComplete() {
				UnityAds.load("Interstitial_Android", loadListener);
				UnityAds.load("Rewarded_Android", loadListener);
			}
			@Override
			public void onInitializationFailed(UnityAds.UnityAdsInitializationError unityAdsInitializationError, String TechnoSahil) {
				 
			}
		});
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	public void _RewardsDialog(final String _title, final String _massage, final double _point, final String _massage1) {
		final AlertDialog dialog1 = new AlertDialog.Builder(DspinActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.material_dialog,null); 
		dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog1.setView(inflate);
		TextView t1 = (TextView) inflate.findViewById(R.id.t1);
		
		TextView t2 = (TextView) inflate.findViewById(R.id.t2);
		
		TextView b1 = (TextView) inflate.findViewById(R.id.b1);
		
		TextView b2 = (TextView) inflate.findViewById(R.id.b2);
		
		LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
		
		LinearLayout linear3 = (LinearLayout) inflate.findViewById(R.id.linear3);
		t1.setText(_title);
		t2.setText(_massage.concat(String.valueOf((long)(_point)).concat(_massage1)));
		b1.setText("");
		b2.setText("COLLECT");
		b1.setVisibility(View.GONE);
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*15);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				bg.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF0F131E}), SketchUi, null);
				bg.setBackground(SketchUiRD);
				bg.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*5);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				b1.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF90CAF9}), SketchUi, null);
				b1.setBackground(SketchUiRD);
				b1.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*5);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				b2.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFEF9A9A}), SketchUi, null);
				b2.setBackground(SketchUiRD);
				b2.setClickable(true);
		}
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog1.dismiss();
			}
		});
		b2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog1.dismiss();
				UnityAds.show(DspinActivity.this, "Interstitial_Android", new UnityAdsShowOptions(), showListener);
				m = new HashMap<>();
				transKey = history.push().getKey();
				m.put("type", "Spin & Earn");
				m.put("date", new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(cal.getTime()));
				m.put("coin", String.valueOf((long)(_point)));
				m.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				m.put("key", transKey);
				history.child(transKey).updateChildren(m);
				m.clear();
				map = new HashMap<>();
				map.put("balance", String.valueOf((long)(balance + _point)));
				map.put("total balance", String.valueOf((long)(totalBalance + _point)));
				All_Users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
				map.clear();
				SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(_point)).concat(" Add to wallet "));
				i_net.setClass(getApplicationContext(), DspinActivity.class);
				startActivity(i_net);
			}
		});
		dialog1.setCancelable(true);
		dialog1.show();
	}
	
	
	public void _RewardedAd() {
	}private IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
		@Override
		public void onUnityAdsAdLoaded(String placementId) {
			 
		}
		@Override
		public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String TechnoSahil) {
			 
		}
	};
	private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
		@Override
		public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String TechnoSahil) {
			 
		}
		@Override
		public void onUnityAdsShowStart(String placementId) {
			 
		}
		@Override
		public void onUnityAdsShowClick(String placementId) {
			 
		}
		@Override
		public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
			if (state.equals(UnityAds.UnityAdsShowCompletionState.COMPLETED)) {
				UnityAds.load(placementId, loadListener);
				if (placementId.equals("Rewarded_Android")) {
					Spin.setEnabled(true);
					spin_list.add(Double.valueOf(3600));
					spin_list.add(Double.valueOf(3636));
					spin_list.add(Double.valueOf(3672));
					spin_list.add(Double.valueOf(3708));
					spin_list.add(Double.valueOf(3744));
					spin_list.add(Double.valueOf(3780));
					spin_list.add(Double.valueOf(3816));
					spin_list.add(Double.valueOf(3852));
					spin_list.add(Double.valueOf(3888));
					spin_list.add(Double.valueOf(3924));
					num = SketchwareUtil.getRandom((int)(0), (int)(9));
					di.setIcon(R.drawable.coinbox_icon_1);
					obj.setTarget(imageview_Spin);
					obj.setPropertyName("rotation");
					obj.setFloatValues((float)(0), (float)(spin_list.get((int)(num)).doubleValue()));
					obj.setDuration((int)(5000));
					obj.setInterpolator(new LinearInterpolator());
					obj.start();
					if (sp_spin.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "").equals("")) {
						sp_spin.edit().putString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "1").commit();
					}
					else {
						sp_spin.edit().putString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), String.valueOf((long)(Double.parseDouble(sp_spin.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "")) + 1))).commit();
					}
				}
			} else {
				UnityAds.load(placementId, loadListener);
			}
		}
	};
	//Blocks are made By Techno Sahil
	{
	}
	
	
	public void _Home_Degin() {
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins.ttf"), 0);
		coin_balance.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans.ttf"), 0);
		Spin.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins.ttf"), 1);
		Time.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins.ttf"), 1);
		_setCornerRadius(Time_Spin, 100, 20, "#00002e");
		_setCornerRadius(linear4, 360, 20, "#00002e");
		_setCornerRadius(imageview_Spin, 360, 20, "#00002e");
		_setCornerRadius(imageview16, 360, 20, "#00002e");
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadii(new float[]{0, 0, 0, 0, 14, 14, 14, 14});
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				top.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
				top.setBackground(SketchUiRD);
				top.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFFDE5C9A,0xFFBD6DEC};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadii(new float[]{360, 360, 360, 360, 360, 360, 360, 360});
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				lin_coins.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), SketchUi, null);
				lin_coins.setBackground(SketchUiRD);
				lin_coins.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF142342,0xFF2D4778};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadii(new float[]{360, 360, 360, 360, 360, 360, 360, 360});
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				Spin.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
				Spin.setBackground(SketchUiRD);
				Spin.setClickable(true);
		}
	}
	
	
	public void _Round(final double _one, final double _two, final double _three, final double _four, final String _color, final View _view) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		s.setColor(Color.parseColor(_color));
		_view.setBackground(s);
	}
	
	
	public void _setCornerRadius(final View _view, final double _radius, final double _shadow, final String _color) {
		//modified by ashishtechnozone
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shadow);
		_view.setBackground(ab);
		
		
	}
	
	
	public void _NavStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _MaterialDialog(final String _title, final String _message, final String _button1text, final String _button2text) {
		final AlertDialog dialog1 = new AlertDialog.Builder(DspinActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.material_dialog,null); 
		dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog1.setView(inflate);
		TextView t1 = (TextView) inflate.findViewById(R.id.t1);
		
		TextView t2 = (TextView) inflate.findViewById(R.id.t2);
		
		TextView b1 = (TextView) inflate.findViewById(R.id.b1);
		
		TextView b2 = (TextView) inflate.findViewById(R.id.b2);
		
		LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
		
		LinearLayout linear3 = (LinearLayout) inflate.findViewById(R.id.linear3);
		t1.setText(_title);
		t2.setText(_message);
		b1.setText(_button1text);
		b2.setText(_button2text);
		if (_button1text.equals("HIDE")) {
			b1.setVisibility(View.GONE);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*15);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				bg.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF0F131E}), SketchUi, null);
				bg.setBackground(SketchUiRD);
				bg.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*5);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				b1.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF90CAF9}), SketchUi, null);
				b1.setBackground(SketchUiRD);
				b1.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*5);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				b2.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFEF9A9A}), SketchUi, null);
				b2.setBackground(SketchUiRD);
				b2.setClickable(true);
		}
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog1.dismiss();
			}
		});
		b2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog1.dismiss();
				if (TechnoSahilIA != null) {
					           TechnoSahilIA.show(DspinActivity.this, new OnUserEarnedRewardListener() {
						@Override
						public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
							
							_loadRewared();
						}
					});
					
				} else {
					
				}
			}
		});
		dialog1.setCancelable(true);
		dialog1.show();
	}
	
	
	public void _loadRewared() {
		
		AdRequest TechnoSahilIA_request = new AdRequest.Builder().build();
		RewardedAd.load(DspinActivity.this, data.getString("admobRewarded", ""),
		TechnoSahilIA_request, new RewardedAdLoadCallback() {
			
			@Override
			public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
				TechnoSahilIA = rewardedAd;
				 
			}
			@Override
			public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
				final int errorCode = loadAdError.getCode();
				final String errorMessage = loadAdError.getMessage();
				
				TechnoSahilIA = null;
				
				 
			}
			
		});
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}