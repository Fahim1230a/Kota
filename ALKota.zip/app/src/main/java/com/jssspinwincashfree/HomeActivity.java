package com.jssspinwincashfree;

import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.airbnb.lottie.*;
import com.anupkumarpanwar.scratchview.*;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.unity3d.ads.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.jetbrains.kotlin.*;
import org.json.*;

public class HomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private HashMap<String, Object> v = new HashMap<>();
	private double coi = 0;
	private HashMap<String, Object> m = new HashMap<>();
	private double balance = 0;
	private HashMap<String, Object> Refer_Code_uesr = new HashMap<>();
	private String Refer_Code = "";
	private double stroke = 0;
	private double radius = 0;
	private double elevation = 0;
	private String transKey = "";
	private HashMap<String, Object> map = new HashMap<>();
	private double number = 0;
	private String app_version = "";
	private String y_version = "";
	private String p_name = "";
	private double position = 0;
	private double num = 0;
	private double n1 = 0;
	private String referText = "";
	private double totalBalance = 0;
	private boolean canCollect = false;
	
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> bannermap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> leadermap = new ArrayList<>();
	
	private LinearLayout bg;
	private LinearLayout linear1;
	private MeowBottomNavigation meow;
	private LinearLayout linear_top;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout lin_coins;
	private ImageView imageview18;
	private TextView coinsText;
	private LinearLayout main;
	private LinearLayout layout1;
	private LinearLayout layout2;
	private LinearLayout layout3;
	private LinearLayout layout4;
	private LinearLayout layout5;
	private RelativeLayout linear_ads;
	private LinearLayout linear_task;
	private TextView textview32;
	private ViewPager viewpager1;
	private LinearLayout recyclerLinear;
	private RecyclerView recyclerview1;
	private LinearLayout daily_bonus;
	private LinearLayout youtube;
	private LinearLayout telegram;
	private ImageView imageview7;
	private TextView textview21;
	private ImageView imageview9;
	private TextView textview23;
	private ImageView imageview20;
	private TextView textview37;
	private TextView top_refer;
	private LottieAnimationView lottie1;
	private LinearLayout linear56;
	private LinearLayout linear57;
	private LinearLayout linear58;
	private LinearLayout linear_code;
	private LinearLayout invite_button;
	private LinearLayout linear_refer;
	private TextView textview48;
	private TextView t1t;
	private TextView tt1;
	private TextView t2t;
	private TextView textview42;
	private TextView t3t;
	private TextView textview44;
	private TextView refferalCode;
	private TextView textview46;
	private ImageView imageview25;
	private TextView textview47;
	private EditText edittext1;
	private Button button1;
	private TextView top_wallet;
	private LinearLayout linear37;
	private LinearLayout linear_history;
	private ImageView imageview16;
	private LinearLayout linear39;
	private LinearLayout linear_button;
	private TextView textview19;
	private TextView textview_bal;
	private TextView textreedem;
	private LinearLayout linear_tab;
	private ViewPager viewpager2;
	private TabLayout tablayout1;
	private TextView top_profile;
	private LinearLayout linear60;
	private LottieAnimationView lottie2;
	private LinearLayout linear61;
	private LinearLayout linear62;
	private LinearLayout linear63;
	private TextView made_in_india;
	private CircleImageView circleimageview1;
	private TextView username;
	private TextView mobileNumber;
	private CardView cardview1;
	private LinearLayout linear;
	private LinearLayout ll1;
	private LinearLayout ll2;
	private LinearLayout ll3;
	private ImageView ii1;
	private TextView tl1;
	private TextView totalCoins;
	private ImageView ii2;
	private TextView tl2;
	private TextView currentCoins;
	private ImageView ii3;
	private TextView tl3;
	private TextView totalWithdrawal;
	private LinearLayout l1;
	private LinearLayout l2;
	private ImageView i1;
	private TextView it1;
	private ImageView i2;
	private TextView it2;
	private LinearLayout l3;
	private LinearLayout l4;
	private ImageView i3;
	private TextView it3;
	private ImageView i4;
	private TextView it4;
	private LinearLayout l5;
	private LinearLayout l6;
	private ImageView i5;
	private TextView it5;
	private ImageView imageview26;
	private TextView textview49;
	private TextView top_leader;
	private LinearLayout linear59;
	private RecyclerView recyclerview2;
	private LinearLayout linear_l2;
	private LinearLayout linear_l1;
	private LinearLayout linear_l3;
	private TextView rank2;
	private CircleImageView profile2;
	private TextView name2;
	private TextView coins2;
	private TextView rank1;
	private CircleImageView profile1;
	private TextView name1;
	private TextView coins1;
	private ImageView crown;
	private TextView rank3;
	private CircleImageView profile3;
	private TextView name3;
	private TextView coins3;
	private ScrollView _drawer_vscroll1;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear2;
	private LinearLayout _drawer_linear3;
	private LottieAnimationView _drawer_lottie1;
	private LinearLayout _drawer_wallet;
	private LinearLayout _drawer_notice;
	private LinearLayout _drawer_share;
	private LinearLayout _drawer_youtube;
	private LinearLayout _drawer_instagram;
	private LinearLayout _drawer_privacy;
	private LinearLayout _drawer_terms;
	private LinearLayout _drawer_linear4;
	private CircleImageView _drawer_circleimageview1;
	private TextView _drawer_username;
	private TextView _drawer_email;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview4;
	private TextView _drawer_textview7;
	private ImageView _drawer_imageview6;
	private TextView _drawer_textview6;
	private ImageView _drawer_imageview9;
	private TextView _drawer_textview10;
	private ImageView _drawer_imageview11;
	private TextView _drawer_textview12;
	private ImageView _drawer_imageview8;
	private TextView _drawer_textview9;
	private ImageView _drawer_imageview7;
	private TextView _drawer_textview8;
	private TextView _drawer_textview_ver;
	
	private DatabaseReference All_Users = _firebase.getReference("All_Users");
	private ChildEventListener _All_Users_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference refer_codes = _firebase.getReference("refer_codes");
	private ChildEventListener _refer_codes_child_listener;
	private DatabaseReference update = _firebase.getReference("update");
	private ChildEventListener _update_child_listener;
	private DatabaseReference history = _firebase.getReference("history");
	private ChildEventListener _history_child_listener;
	private Calendar cal = Calendar.getInstance();
	private ObjectAnimator obj = new ObjectAnimator();
	private TimerTask t;
	private SharedPreferences design;
	private SharedPreferences daily_cheak;
	private Intent intent = new Intent();
	private TimerTask t1;
	private DatabaseReference bAds = _firebase.getReference("bAds");
	private ChildEventListener _bAds_child_listener;
	private AlertDialog.Builder dialog;
	private Intent intent1 = new Intent();
	private SharedPreferences sp_spin;
	private SharedPreferences sp;
	private SharedPreferences sp_sc;
	private SharedPreferences sp_video;
	private DatabaseReference invite_link = _firebase.getReference("invite_link");
	private ChildEventListener _invite_link_child_listener;
	private FragFragmentAdapter frag;
	private Intent Harsh_Tek = new Intent();
	private SharedPreferences data;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(HomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		bg = findViewById(R.id.bg);
		linear1 = findViewById(R.id.linear1);
		meow = findViewById(R.id.meow);
		linear_top = findViewById(R.id.linear_top);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		lin_coins = findViewById(R.id.lin_coins);
		imageview18 = findViewById(R.id.imageview18);
		coinsText = findViewById(R.id.coinsText);
		main = findViewById(R.id.main);
		layout1 = findViewById(R.id.layout1);
		layout2 = findViewById(R.id.layout2);
		layout3 = findViewById(R.id.layout3);
		layout4 = findViewById(R.id.layout4);
		layout5 = findViewById(R.id.layout5);
		linear_ads = findViewById(R.id.linear_ads);
		linear_task = findViewById(R.id.linear_task);
		textview32 = findViewById(R.id.textview32);
		viewpager1 = findViewById(R.id.viewpager1);
		recyclerLinear = findViewById(R.id.recyclerLinear);
		recyclerview1 = findViewById(R.id.recyclerview1);
		daily_bonus = findViewById(R.id.daily_bonus);
		youtube = findViewById(R.id.youtube);
		telegram = findViewById(R.id.telegram);
		imageview7 = findViewById(R.id.imageview7);
		textview21 = findViewById(R.id.textview21);
		imageview9 = findViewById(R.id.imageview9);
		textview23 = findViewById(R.id.textview23);
		imageview20 = findViewById(R.id.imageview20);
		textview37 = findViewById(R.id.textview37);
		top_refer = findViewById(R.id.top_refer);
		lottie1 = findViewById(R.id.lottie1);
		linear56 = findViewById(R.id.linear56);
		linear57 = findViewById(R.id.linear57);
		linear58 = findViewById(R.id.linear58);
		linear_code = findViewById(R.id.linear_code);
		invite_button = findViewById(R.id.invite_button);
		linear_refer = findViewById(R.id.linear_refer);
		textview48 = findViewById(R.id.textview48);
		t1t = findViewById(R.id.t1t);
		tt1 = findViewById(R.id.tt1);
		t2t = findViewById(R.id.t2t);
		textview42 = findViewById(R.id.textview42);
		t3t = findViewById(R.id.t3t);
		textview44 = findViewById(R.id.textview44);
		refferalCode = findViewById(R.id.refferalCode);
		textview46 = findViewById(R.id.textview46);
		imageview25 = findViewById(R.id.imageview25);
		textview47 = findViewById(R.id.textview47);
		edittext1 = findViewById(R.id.edittext1);
		button1 = findViewById(R.id.button1);
		top_wallet = findViewById(R.id.top_wallet);
		linear37 = findViewById(R.id.linear37);
		linear_history = findViewById(R.id.linear_history);
		imageview16 = findViewById(R.id.imageview16);
		linear39 = findViewById(R.id.linear39);
		linear_button = findViewById(R.id.linear_button);
		textview19 = findViewById(R.id.textview19);
		textview_bal = findViewById(R.id.textview_bal);
		textreedem = findViewById(R.id.textreedem);
		linear_tab = findViewById(R.id.linear_tab);
		viewpager2 = findViewById(R.id.viewpager2);
		tablayout1 = findViewById(R.id.tablayout1);
		top_profile = findViewById(R.id.top_profile);
		linear60 = findViewById(R.id.linear60);
		lottie2 = findViewById(R.id.lottie2);
		linear61 = findViewById(R.id.linear61);
		linear62 = findViewById(R.id.linear62);
		linear63 = findViewById(R.id.linear63);
		made_in_india = findViewById(R.id.made_in_india);
		circleimageview1 = findViewById(R.id.circleimageview1);
		username = findViewById(R.id.username);
		mobileNumber = findViewById(R.id.mobileNumber);
		cardview1 = findViewById(R.id.cardview1);
		linear = findViewById(R.id.linear);
		ll1 = findViewById(R.id.ll1);
		ll2 = findViewById(R.id.ll2);
		ll3 = findViewById(R.id.ll3);
		ii1 = findViewById(R.id.ii1);
		tl1 = findViewById(R.id.tl1);
		totalCoins = findViewById(R.id.totalCoins);
		ii2 = findViewById(R.id.ii2);
		tl2 = findViewById(R.id.tl2);
		currentCoins = findViewById(R.id.currentCoins);
		ii3 = findViewById(R.id.ii3);
		tl3 = findViewById(R.id.tl3);
		totalWithdrawal = findViewById(R.id.totalWithdrawal);
		l1 = findViewById(R.id.l1);
		l2 = findViewById(R.id.l2);
		i1 = findViewById(R.id.i1);
		it1 = findViewById(R.id.it1);
		i2 = findViewById(R.id.i2);
		it2 = findViewById(R.id.it2);
		l3 = findViewById(R.id.l3);
		l4 = findViewById(R.id.l4);
		i3 = findViewById(R.id.i3);
		it3 = findViewById(R.id.it3);
		i4 = findViewById(R.id.i4);
		it4 = findViewById(R.id.it4);
		l5 = findViewById(R.id.l5);
		l6 = findViewById(R.id.l6);
		i5 = findViewById(R.id.i5);
		it5 = findViewById(R.id.it5);
		imageview26 = findViewById(R.id.imageview26);
		textview49 = findViewById(R.id.textview49);
		top_leader = findViewById(R.id.top_leader);
		linear59 = findViewById(R.id.linear59);
		recyclerview2 = findViewById(R.id.recyclerview2);
		linear_l2 = findViewById(R.id.linear_l2);
		linear_l1 = findViewById(R.id.linear_l1);
		linear_l3 = findViewById(R.id.linear_l3);
		rank2 = findViewById(R.id.rank2);
		profile2 = findViewById(R.id.profile2);
		name2 = findViewById(R.id.name2);
		coins2 = findViewById(R.id.coins2);
		rank1 = findViewById(R.id.rank1);
		profile1 = findViewById(R.id.profile1);
		name1 = findViewById(R.id.name1);
		coins1 = findViewById(R.id.coins1);
		crown = findViewById(R.id.crown);
		rank3 = findViewById(R.id.rank3);
		profile3 = findViewById(R.id.profile3);
		name3 = findViewById(R.id.name3);
		coins3 = findViewById(R.id.coins3);
		_drawer_vscroll1 = _nav_view.findViewById(R.id.vscroll1);
		_drawer_linear1 = _nav_view.findViewById(R.id.linear1);
		_drawer_linear2 = _nav_view.findViewById(R.id.linear2);
		_drawer_linear3 = _nav_view.findViewById(R.id.linear3);
		_drawer_lottie1 = _nav_view.findViewById(R.id.lottie1);
		_drawer_wallet = _nav_view.findViewById(R.id.wallet);
		_drawer_notice = _nav_view.findViewById(R.id.notice);
		_drawer_share = _nav_view.findViewById(R.id.share);
		_drawer_youtube = _nav_view.findViewById(R.id.youtube);
		_drawer_instagram = _nav_view.findViewById(R.id.instagram);
		_drawer_privacy = _nav_view.findViewById(R.id.privacy);
		_drawer_terms = _nav_view.findViewById(R.id.terms);
		_drawer_linear4 = _nav_view.findViewById(R.id.linear4);
		_drawer_circleimageview1 = _nav_view.findViewById(R.id.circleimageview1);
		_drawer_username = _nav_view.findViewById(R.id.username);
		_drawer_email = _nav_view.findViewById(R.id.email);
		_drawer_imageview3 = _nav_view.findViewById(R.id.imageview3);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview4 = _nav_view.findViewById(R.id.imageview4);
		_drawer_textview7 = _nav_view.findViewById(R.id.textview7);
		_drawer_imageview6 = _nav_view.findViewById(R.id.imageview6);
		_drawer_textview6 = _nav_view.findViewById(R.id.textview6);
		_drawer_imageview9 = _nav_view.findViewById(R.id.imageview9);
		_drawer_textview10 = _nav_view.findViewById(R.id.textview10);
		_drawer_imageview11 = _nav_view.findViewById(R.id.imageview11);
		_drawer_textview12 = _nav_view.findViewById(R.id.textview12);
		_drawer_imageview8 = _nav_view.findViewById(R.id.imageview8);
		_drawer_textview9 = _nav_view.findViewById(R.id.textview9);
		_drawer_imageview7 = _nav_view.findViewById(R.id.imageview7);
		_drawer_textview8 = _nav_view.findViewById(R.id.textview8);
		_drawer_textview_ver = _nav_view.findViewById(R.id.textview_ver);
		auth = FirebaseAuth.getInstance();
		design = getSharedPreferences("design", Activity.MODE_PRIVATE);
		daily_cheak = getSharedPreferences("daily_cheak", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		sp_spin = getSharedPreferences("sp_spin", Activity.MODE_PRIVATE);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		sp_sc = getSharedPreferences("sp_sc", Activity.MODE_PRIVATE);
		sp_video = getSharedPreferences("sp_video", Activity.MODE_PRIVATE);
		frag = new FragFragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.openDrawer(GravityCompat.START);
			}
		});
		
		viewpager1.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			@Override
			public void onPageScrolled(int _position, float _positionOffset, int _positionOffsetPixels) {
				
			}
			
			@Override
			public void onPageSelected(int _position) {
				position = _position;
				num = _position;
				recyclerview1.setAdapter(new Recyclerview1Adapter(bannermap));
				recyclerview1.smoothScrollToPosition((int)_position);
			}
			
			@Override
			public void onPageScrollStateChanged(int _scrollState) {
				
			}
		});
		
		daily_bonus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (daily_cheak.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "").equals("")) {
					_MaterialDialog("Daily Check!", "Collect now your daily reward.", "CANCEL", "COLLECT");
				}
				else {
					_MaterialDialog("Daily Check!", "You have already collected your daily reward.", "HIDE", "OK");
				}
			}
		});
		
		youtube.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setClass(getApplicationContext(), RefCodeActivity.class);
				Harsh_Tek.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(Harsh_Tek);
			}
		});
		
		telegram.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ArticleTaskActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		invite_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent textsend = new Intent(Intent.ACTION_SEND);
				textsend.setType("text/plain");
				textsend.putExtra(Intent.EXTRA_TEXT,(_formatText(referText)));
				startActivity(Intent.createChooser(textsend, "Share"));
			}
		});
		
		textview48.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_refer.setVisibility(View.VISIBLE);
				_TransitionManager(layout2, 300);
			}
		});
		
		textview46.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", refferalCode.getText().toString()));
				SketchwareUtil.showMessage(getApplicationContext(), "Copied!");
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().trim().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please enter a referral code");
				}
				else {
					if (edittext1.getText().toString().trim().equals(Refer_Code)) {
						SketchwareUtil.showMessage(getApplicationContext(), "Please enter a referral code");
					}
					else {
						if (!list.contains(edittext1.getText().toString().trim())) {
							SketchwareUtil.showMessage(getApplicationContext(), "Please enter a valid referral code");
						}
						else {
							UnityAds.show(HomeActivity.this, "Interstitial_Android", new UnityAdsShowOptions(), showListener);
							intent.setClass(getApplicationContext(), RffActivity.class);
							intent.putExtra("code", edittext1.getText().toString().trim());
							intent.putExtra("coins", String.valueOf((long)(balance)));
							intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(intent);
						}
					}
				}
			}
		});
		
		linear_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), RedeemMethodActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		tablayout1.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
			@Override
			public void onTabSelected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				viewpager2.setCurrentItem((int)_position);
			}
			
			@Override
			public void onTabUnselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
			
			@Override
			public void onTabReselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
		});
		
		l1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), WalletActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		l2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setAction(Intent.ACTION_VIEW);
				Harsh_Tek.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.jssspinwincashfree"));
				startActivity(Harsh_Tek);
			}
		});
		
		l3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setAction(Intent.ACTION_VIEW);
				Harsh_Tek.setData(Uri.parse("https://docs.google.com/document/d/1xievJkCQN6ynUxqkhhNTj_9RTjfwJckTvrbe-3fY0Bc/edit?usp=sharing"));
				startActivity(Harsh_Tek);
			}
		});
		
		l4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setAction(Intent.ACTION_VIEW);
				Harsh_Tek.setData(Uri.parse("https://docs.google.com/document/d/18VELqlZK8UMFbmBOihKdHFTG7HWDSV8YHO3f16poo44/edit?usp=sharing"));
				startActivity(Harsh_Tek);
			}
		});
		
		l5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_logout("", "", "", "");
			}
		});
		
		l6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setAction(Intent.ACTION_VIEW);
				Harsh_Tek.setData(Uri.parse("https://wa.me/+919912037393"));
				startActivity(Harsh_Tek);
			}
		});
		
		_All_Users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("name")) {
						username.setText(_childValue.get("name").toString());
						_drawer_username.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("email")) {
						mobileNumber.setText(_childValue.get("email").toString());
						_drawer_email.setText(_childValue.get("email").toString());
					}
					if (_childValue.containsKey("balance")) {
						balance = Double.parseDouble(_childValue.get("balance").toString());
						coinsText.setText(_childValue.get("balance").toString().concat(" Coins"));
						textview_bal.setText(_childValue.get("balance").toString());
						currentCoins.setText(_childValue.get("balance").toString());
					}
					if (_childValue.containsKey("total balance")) {
						totalBalance = Double.parseDouble(_childValue.get("total balance").toString());
						totalCoins.setText(_childValue.get("total balance").toString());
					}
					if (_childValue.containsKey("deposit balance")) {
						totalWithdrawal.setText(_childValue.get("deposit balance").toString());
					}
					if (_childValue.containsKey("Refer_Code")) {
						Refer_Code = _childValue.get("Refer_Code").toString();
						refferalCode.setText(_childValue.get("Refer_Code").toString());
					}
					else {
						_refer_code();
					}
					if (_childValue.containsKey("Refer")) {
						textview48.setVisibility(View.GONE);
						linear_refer.setVisibility(View.GONE);
					}
					else {
						textview48.setVisibility(View.VISIBLE);
					}
					if (_childValue.get("block").toString().equals("true")) {
						intent.setClass(getApplicationContext(), BlockActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
						finish();
					}
					else {
						
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("name")) {
						username.setText(_childValue.get("name").toString());
						_drawer_username.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("email")) {
						mobileNumber.setText(_childValue.get("email").toString());
						_drawer_email.setText(_childValue.get("email").toString());
					}
					if (_childValue.containsKey("balance")) {
						balance = Double.parseDouble(_childValue.get("balance").toString());
						coinsText.setText(_childValue.get("balance").toString().concat(" Coins"));
						textview_bal.setText(_childValue.get("balance").toString());
					}
					if (_childValue.containsKey("total balance")) {
						totalBalance = Double.parseDouble(_childValue.get("total balance").toString());
						totalCoins.setText(_childValue.get("total balance").toString());
					}
					if (_childValue.containsKey("deposit balance")) {
						totalWithdrawal.setText(_childValue.get("deposit balance").toString());
					}
					if (_childValue.containsKey("Refer_Code")) {
						Refer_Code = _childValue.get("Refer_Code").toString();
						refferalCode.setText(_childValue.get("Refer_Code").toString());
					}
					else {
						_refer_code();
					}
					if (_childValue.containsKey("Refer")) {
						textview48.setVisibility(View.GONE);
						linear_refer.setVisibility(View.GONE);
					}
					else {
						
					}
					if (_childValue.get("block").toString().equals("true")) {
						intent.setClass(getApplicationContext(), BlockActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
						finish();
					}
					else {
						
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		All_Users.addChildEventListener(_All_Users_child_listener);
		
		_refer_codes_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Refer_Codes")) {
					SketchwareUtil.getAllKeysFromMap(_childValue, list);
				}
				else {
					
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Refer_Codes")) {
					SketchwareUtil.getAllKeysFromMap(_childValue, list);
				}
				else {
					
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		refer_codes.addChildEventListener(_refer_codes_child_listener);
		
		_update_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				app_version = _childValue.get("version").toString();
				if ((Double.parseDouble(y_version) == Double.parseDouble(app_version)) || (Double.parseDouble(y_version) > Double.parseDouble(app_version))) {
					
				}
				else {
					if (Double.parseDouble(y_version) < Double.parseDouble(app_version)) {
						intent.setClass(getApplicationContext(), UpdatesActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
						finish();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		update.addChildEventListener(_update_child_listener);
		
		_history_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		history.addChildEventListener(_history_child_listener);
		
		_bAds_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				bannermap.add(_childValue);
				viewpager1.setAdapter(new Viewpager1Adapter(bannermap));
				recyclerview1.setAdapter(new Recyclerview1Adapter(bannermap));
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				n1 = 0;
				for(int _repeat11 = 0; _repeat11 < (int)(bannermap.size()); _repeat11++) {
					if (bannermap.get((int)n1).get("key").toString().equals(_childKey)) {
						bannermap.remove((int)(n1));
						bannermap.add((int)n1, _childValue);
					}
					n1++;
				}
				viewpager1.setAdapter(new Viewpager1Adapter(bannermap));
				recyclerview1.setAdapter(new Recyclerview1Adapter(listmap));
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		bAds.addChildEventListener(_bAds_child_listener);
		
		_invite_link_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				try {
					referText = _childValue.get("text").toString();
				} catch (Exception e) {
					 
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				try {
					referText = _childValue.get("text").toString();
				} catch (Exception e) {
					 
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		invite_link.addChildEventListener(_invite_link_child_listener);
		
		_drawer_wallet.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), WalletActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		_drawer_notice.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), NotificationActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		_drawer_share.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setAction(Intent.ACTION_VIEW);
				Harsh_Tek.setData(Uri.parse("mailto:jsswayofficial@gmail.com"));
				startActivity(Harsh_Tek);
			}
		});
		
		_drawer_youtube.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setClass(getApplicationContext(), RefCodeActivity.class);
				Harsh_Tek.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(Harsh_Tek);
			}
		});
		
		_drawer_instagram.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setAction(Intent.ACTION_VIEW);
				Harsh_Tek.setData(Uri.parse("https://wa.me/+919912037393"));
				startActivity(Harsh_Tek);
			}
		});
		
		_drawer_privacy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setAction(Intent.ACTION_VIEW);
				Harsh_Tek.setData(Uri.parse("https://docs.google.com/document/d/18VELqlZK8UMFbmBOihKdHFTG7HWDSV8YHO3f16poo44/edit?usp=sharing"));
				startActivity(Harsh_Tek);
			}
		});
		
		_drawer_terms.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Harsh_Tek.setAction(Intent.ACTION_VIEW);
				Harsh_Tek.setData(Uri.parse("https://docs.google.com/document/d/1xievJkCQN6ynUxqkhhNTj_9RTjfwJckTvrbe-3fY0Bc/edit?usp=sharing"));
				startActivity(Harsh_Tek);
			}
		});
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		vscroll1.setFillViewport(true);
		vscroll1.setVerticalScrollBarEnabled(false); vscroll1.setHorizontalScrollBarEnabled(false);
		_drawer_vscroll1.setFillViewport(true);
		_drawer_vscroll1.setVerticalScrollBarEnabled(false); _drawer_vscroll1.setHorizontalScrollBarEnabled(false);
		_NavStatusBarColor("#171E2E", "#171E2E");
		_Home_Degin();
		UnityAds.initialize(getApplicationContext(), data.getString("unityID", ""), false, new IUnityAdsInitializationListener() {
			@Override
			public void onInitializationComplete() {
				UnityAds.load("Interstitial_Android", loadListener);
				UnityAds.load("Rewarded_Android", loadListener);
			}
			@Override
			public void onInitializationFailed(UnityAds.UnityAdsInitializationError unityAdsInitializationError, String TechnoSahil) {
				 
			}
		});
		_progress();
		canCollect = false;
		linear_refer.setVisibility(View.GONE);
		layout1.setVisibility(View.VISIBLE);
		layout2.setVisibility(View.GONE);
		layout3.setVisibility(View.GONE);
		layout4.setVisibility(View.GONE);
		layout5.setVisibility(View.GONE);
		_TransitionManager(main, 300);
		p_name = getApplicationContext().getPackageName();
		android.content.pm.PackageManager pm = getPackageManager();
		try {
			android.content.pm.PackageInfo pinfo = getPackageManager().getPackageInfo( p_name, android.content.pm.PackageManager.GET_ACTIVITIES);
			y_version = pinfo.versionName; }
		catch (Exception e){ showMessage(e.toString()); }
		_drawer_textview_ver.setText("Version: ".concat(y_version));
		final float scaleFactor = 0.94f; viewpager1.setPageMargin(-15);
		
		viewpager1.setOffscreenPageLimit(2); viewpager1.setPageTransformer(false, new ViewPager.PageTransformer() {
			    @Override public void transformPage(@NonNull View page1, float position) {
				        page1.setScaleY((1 - Math.abs(position) * (1 - scaleFactor)));
				        page1.setScaleX(scaleFactor + Math.abs(position) * (1 - scaleFactor)); 
				        } });
		
		tablayout1.setTabTextColors(0xFFE0E0E0, 0xFF3D9CF8);
		tablayout1.setSelectedTabIndicatorColor(0xFF3D9CF8);
		frag.setTabCount(2);
		viewpager2.setAdapter(frag);
		tablayout1.setupWithViewPager(viewpager2);
		viewpager2.setCurrentItem((int)0);
		((PagerAdapter)viewpager2.getAdapter()).notifyDataSetChanged();
		viewpager1.setAdapter(new Viewpager1Adapter(bannermap));
		((PagerAdapter)viewpager1.getAdapter()).notifyDataSetChanged();
		recyclerview1.setAdapter(new Recyclerview1Adapter(bannermap));
		recyclerview1.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		recyclerview2.setAdapter(new Recyclerview2Adapter(leadermap));
		recyclerview2.setLayoutManager(new LinearLayoutManager(this));
		position = 0;
		num = 0;
		t1 = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						viewpager1.setCurrentItem((int)num);
						num++;
						if (num == bannermap.size()) {
							num = 0;
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t1, (int)(0), (int)(2000));
		meow.add(new MeowBottomNavigation.Model((int)0, R.drawable.but_1));
		meow.add(new MeowBottomNavigation.Model((int)1, R.drawable.but_2));
		meow.add(new MeowBottomNavigation.Model((int)2, R.drawable.but_3));
		meow.add(new MeowBottomNavigation.Model((int)3, R.drawable.but_4));
		meow.add(new MeowBottomNavigation.Model((int)4, R.drawable.but_5));
		meow.setOnClickMenuListener(new MeowBottomNavigation.ClickListener() {
			@Override
			public void onClickItem(MeowBottomNavigation.Model item) {
				if (item.getId() == (int)0) {
					linear_top.setVisibility(View.VISIBLE);
					linear_refer.setVisibility(View.GONE);
					top_refer.setVisibility(View.GONE);
					top_leader.setVisibility(View.GONE);
					top_wallet.setVisibility(View.GONE);
					top_profile.setVisibility(View.GONE);
					layout1.setVisibility(View.VISIBLE);
					layout2.setVisibility(View.GONE);
					layout3.setVisibility(View.GONE);
					layout4.setVisibility(View.GONE);
					layout5.setVisibility(View.GONE);
					_TransitionManager(main, 300);
				}
				if (item.getId() == (int)1) {
					linear_top.setVisibility(View.GONE);
					top_refer.setVisibility(View.GONE);
					linear_refer.setVisibility(View.GONE);
					top_leader.setVisibility(View.VISIBLE);
					top_wallet.setVisibility(View.GONE);
					top_profile.setVisibility(View.GONE);
					layout1.setVisibility(View.GONE);
					layout2.setVisibility(View.GONE);
					layout3.setVisibility(View.GONE);
					layout4.setVisibility(View.GONE);
					layout5.setVisibility(View.VISIBLE);
					_TransitionManager(main, 300);
				}
				if (item.getId() == (int)2) {
					linear_top.setVisibility(View.GONE);
					linear_refer.setVisibility(View.GONE);
					top_refer.setVisibility(View.VISIBLE);
					top_leader.setVisibility(View.GONE);
					top_wallet.setVisibility(View.GONE);
					top_profile.setVisibility(View.GONE);
					layout1.setVisibility(View.GONE);
					layout2.setVisibility(View.VISIBLE);
					layout3.setVisibility(View.GONE);
					layout4.setVisibility(View.GONE);
					layout5.setVisibility(View.GONE);
					_TransitionManager(main, 300);
				}
				if (item.getId() == (int)3) {
					linear_top.setVisibility(View.GONE);
					linear_refer.setVisibility(View.GONE);
					top_refer.setVisibility(View.GONE);
					top_leader.setVisibility(View.GONE);
					top_wallet.setVisibility(View.VISIBLE);
					top_profile.setVisibility(View.GONE);
					layout1.setVisibility(View.GONE);
					layout2.setVisibility(View.GONE);
					layout3.setVisibility(View.VISIBLE);
					layout4.setVisibility(View.GONE);
					layout5.setVisibility(View.GONE);
					_TransitionManager(main, 300);
				}
				if (item.getId() == (int)4) {
					linear_top.setVisibility(View.GONE);
					linear_refer.setVisibility(View.GONE);
					top_refer.setVisibility(View.GONE);
					top_leader.setVisibility(View.GONE);
					top_wallet.setVisibility(View.GONE);
					top_profile.setVisibility(View.VISIBLE);
					layout1.setVisibility(View.GONE);
					layout2.setVisibility(View.GONE);
					layout3.setVisibility(View.GONE);
					layout4.setVisibility(View.VISIBLE);
					layout5.setVisibility(View.GONE);
					_TransitionManager(main, 300);
				}
			}
		});
		meow.setOnReselectListener(new MeowBottomNavigation.ReselectListener() {
			@Override
			public void onReselectItem(MeowBottomNavigation.Model item) {
				 
			}
		});
		meow.setOnShowListener(new MeowBottomNavigation.ShowListener() {
			@Override
			public void onShowItem(MeowBottomNavigation.Model item) {
				 
			}
		});
		meow.show((int)0, true);
	}
	
	public class FragFragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public FragFragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			if (_position == 0) {
				return "Coin History";
			}
			if (_position == 1) {
				return "Reedem History";
			}
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new HistoryCFragmentActivity();
			}
			if (_position == 1) {
				return new ReedemHFragmentActivity();
			}
			return null;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		_progress();
		_leaderdata();
	}
	
	@Override
	public void onBackPressed() {
		_exitdialog("", "", "", "");
	}
	public void _refer_code() {
		Refer_Code = _refferalCode();
		if (list.contains(Refer_Code)) {
			_refer_code();
		}
		else {
			Refer_Code_uesr = new HashMap<>();
			Refer_Code_uesr.put("Refer_Code", Refer_Code);
			All_Users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(Refer_Code_uesr);
			v = new HashMap<>();
			v.put(Refer_Code, FirebaseAuth.getInstance().getCurrentUser().getUid());
			refer_codes.child("Refer_Codes").updateChildren(v);
		}
		refferalCode.setText(Refer_Code);
	}
	
	
	public void _setCornerRadius(final View _view, final double _radius, final double _shadow, final String _color) {
		//modified by ashishtechnozone
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shadow);
		_view.setBackground(ab);
		
		
	}
	
	
	public void _Round(final double _one, final double _two, final double _three, final double _four, final String _color, final View _view) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		s.setColor(Color.parseColor(_color));
		_view.setBackground(s);
	}
	
	
	public void _Home_Degin() {
		_Drawer_Ui();
		_openDriver();
		_Icon_Colour(imageview1, "#FFFFFF");
		t1t.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3D9CF8));
		t2t.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3D9CF8));
		t3t.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF3D9CF8));
		coinsText.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans.ttf"), 0);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins.ttf"), 0);
		textview21.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins.ttf"), 0);
		textview23.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins.ttf"), 0);
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				linear_top.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF8BBD0}), SketchUi, null);
				linear_top.setBackground(SketchUiRD);
				linear_top.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				top_refer.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF8BBD0}), SketchUi, null);
				top_refer.setBackground(SketchUiRD);
				top_refer.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				top_leader.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF8BBD0}), SketchUi, null);
				top_leader.setBackground(SketchUiRD);
				top_leader.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				top_wallet.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF8BBD0}), SketchUi, null);
				top_wallet.setBackground(SketchUiRD);
				top_wallet.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				top_profile.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF8BBD0}), SketchUi, null);
				top_profile.setBackground(SketchUiRD);
				top_profile.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*14);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				daily_bonus.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF424242}), SketchUi, null);
				daily_bonus.setBackground(SketchUiRD);
				daily_bonus.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*14);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				youtube.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF424242}), SketchUi, null);
				youtube.setBackground(SketchUiRD);
				youtube.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*14);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				telegram.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF424242}), SketchUi, null);
				telegram.setBackground(SketchUiRD);
				telegram.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFFDE5C9A,0xFFBD6DEC};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*360);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				lin_coins.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF8BBD0}), SketchUi, null);
				lin_coins.setBackground(SketchUiRD);
				lin_coins.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*360);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				linear_code.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF8BBD0}), SketchUi, null);
				linear_code.setBackground(SketchUiRD);
				linear_code.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF142342,0xFF2D4778};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*360);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				invite_button.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				invite_button.setBackground(SketchUiRD);
				invite_button.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*360);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				linear_refer.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF8BBD0}), SketchUi, null);
				linear_refer.setBackground(SketchUiRD);
				linear_refer.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF142342,0xFF2D4778};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*360);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				button1.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				button1.setBackground(SketchUiRD);
				button1.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF142342,0xFF2D4778};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*360);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				linear_button.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear_button.setBackground(SketchUiRD);
				linear_button.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF142342,0xFF2D4778};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*14);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				linear.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear.setBackground(SketchUiRD);
				linear.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				l1.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				l1.setBackground(SketchUiRD);
				l1.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				l2.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				l2.setBackground(SketchUiRD);
				l2.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				l3.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				l3.setBackground(SketchUiRD);
				l3.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				l4.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				l4.setBackground(SketchUiRD);
				l4.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				l5.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				l5.setBackground(SketchUiRD);
				l5.setClickable(true);
		}
	}
	
	
	public void _Icon_Colour(final ImageView _iconview, final String _colour) {
		_iconview.getDrawable().setColorFilter(Color.parseColor(_colour), PorterDuff.Mode.SRC_IN);
	}
	
	
	public void _openDriver() {
		if (false) {
			getSupportActionBar().show();
		}
		else {
			getSupportActionBar().hide();
		}
	}
	
	
	public void _Drawer_Ui() {
		final LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view); _nav_view.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				_drawer_wallet.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				_drawer_wallet.setBackground(SketchUiRD);
				_drawer_wallet.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				_drawer_notice.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				_drawer_notice.setBackground(SketchUiRD);
				_drawer_notice.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				_drawer_share.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				_drawer_share.setBackground(SketchUiRD);
				_drawer_share.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				_drawer_terms.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				_drawer_terms.setBackground(SketchUiRD);
				_drawer_terms.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				_drawer_privacy.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				_drawer_privacy.setBackground(SketchUiRD);
				_drawer_privacy.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				_drawer_youtube.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				_drawer_youtube.setBackground(SketchUiRD);
				_drawer_youtube.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*0);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				_drawer_instagram.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
				_drawer_instagram.setBackground(SketchUiRD);
				_drawer_instagram.setClickable(true);
		}
	}
	
	
	public void _RewardedAd() {
	}private IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
		@Override
		public void onUnityAdsAdLoaded(String placementId) {
			 
		}
		@Override
		public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String TechnoSahil) {
			 
		}
	};
	private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
		@Override
		public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String TechnoSahil) {
			 
		}
		@Override
		public void onUnityAdsShowStart(String placementId) {
			 
		}
		@Override
		public void onUnityAdsShowClick(String placementId) {
			 
		}
		@Override
		public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
			if (state.equals(UnityAds.UnityAdsShowCompletionState.COMPLETED)) {
				UnityAds.load(placementId, loadListener);
				if (placementId.equals("Rewarded_Android")) {
					coi = SketchwareUtil.getRandom((int)(5), (int)(10));
					canCollect = true;
					_MaterialDialog("Congratulations", "You won ".concat(String.valueOf((long)(coi)).concat(" Coins, Kindly click on collect button to collect it.")), "HIDE", "COLLECT");
				}
			} else {
				UnityAds.load(placementId, loadListener);
			}
		}
	};
	//Blocks are made By Techno Sahil
	{
	}
	
	
	public void _NavStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _progress() {
		
	}
	
	
	public void _s(final View _back, final View _progress, final double _num, final double _totalNum) {
		//Made By Techno Sahil
		_progress.setLayoutParams(new LinearLayout.LayoutParams((int) ((_num / _totalNum) * _back.getWidth()),(int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT)));
		_TransitionManager(_back, 300);
	}
	
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public String _refferalCode() {
		String code = "";
		String all = "A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0U1V2W3X4Y5Z6789";
		double pos = 0;
		ArrayList<String> l = new ArrayList<>();
		l.clear();
		for(int _repeat15 = 0; _repeat15 < (int)(all.length()); _repeat15++) {
			l.add(all.substring((int)(pos), (int)(pos + 1)));
			pos++;
		}
		for(int _repeat26 = 0; _repeat26 < (int)(8); _repeat26++) {
			code = code.replace("", "").concat(l.get((int)(SketchwareUtil.getRandom((int)(0), (int)(l.size() - 1)))));
		}
		return (code);
	}
	
	
	public String _formatText(final String _text) {
		return (_text.replace("%refferalCode%", Refer_Code));
	}
	
	
	public void _leaderdata() {
		leadermap.clear();
		All_Users.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				leadermap = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						leadermap.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				try {
					_SortMap(leadermap, "total balance", true, false);
				} catch (Exception e) {
					 
				}
				_leader1();
				_leader2();
				_leader3();
				recyclerview2.setAdapter(new Recyclerview2Adapter(leadermap));
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public void _leader1() {
		try {
			name1.setText(leadermap.get((int)0).get("name").toString());
			coins1.setText(leadermap.get((int)0).get("total balance").toString());
		} catch (Exception e) {
			 
		}
	}
	
	
	public void _leader2() {
		try {
			name2.setText(leadermap.get((int)1).get("name").toString());
			coins2.setText(leadermap.get((int)1).get("total balance").toString());
		} catch (Exception e) {
			 
		}
	}
	
	
	public void _leader3() {
		try {
			name3.setText(leadermap.get((int)2).get("name").toString());
			coins3.setText(leadermap.get((int)2).get("total balance").toString());
		} catch (Exception e) {
			 
		}
	}
	
	
	public void _SortMap(final ArrayList<HashMap<String, Object>> _listMap, final String _key, final boolean _isNumber, final boolean _Ascending) {
		final Object _keyObject = _key;
		Collections.sort(_listMap, new Comparator<HashMap<String,Object>>(){
			public int compare(HashMap<String,Object> _compareMap1, HashMap<String,Object> _compareMap2){
				if (_isNumber) {
					int _count1 = Integer.valueOf(_compareMap1.get(_key).toString());
					int _count2 = Integer.valueOf(_compareMap2.get(_key).toString());
					if (_Ascending) {
						return _count1 < _count2 ? -1 : _count1 < _count2 ? 1 : 0;
					}
					else {
						return _count1 > _count2 ? -1 : _count1 > _count2 ? 1 : 0;
					}
				}
				else {
					if (_Ascending) {
						return (_compareMap1.get(_key).toString()).compareTo(_compareMap2.get(_key).toString());
					}
					else {
						return (_compareMap2.get(_key).toString()).compareTo(_compareMap1.get(_key).toString());
					}
				}
			}});
		///Use true or false blocks if sorting number of listmap
	}
	
	
	public void _MaterialDialog(final String _title, final String _message, final String _button1text, final String _button2text) {
		final AlertDialog dialog1 = new AlertDialog.Builder(HomeActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.material_dialog,null); 
		dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog1.setView(inflate);
		TextView t1 = (TextView) inflate.findViewById(R.id.t1);
		
		TextView t2 = (TextView) inflate.findViewById(R.id.t2);
		
		TextView b1 = (TextView) inflate.findViewById(R.id.b1);
		
		TextView b2 = (TextView) inflate.findViewById(R.id.b2);
		
		LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
		
		LinearLayout linear3 = (LinearLayout) inflate.findViewById(R.id.linear3);
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_regular.ttf"), 0);
		t1.setText(_title);
		t2.setText(_message);
		b1.setText(_button1text);
		b2.setText(_button2text);
		if (_button1text.equals("HIDE")) {
			b1.setVisibility(View.GONE);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*15);
				SketchUi.setStroke(d*0,0xFF0F131E);
				bg.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
				bg.setBackground(SketchUiRD);
				bg.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*5);
				SketchUi.setStroke(d*0,0xFFFF00AA);
				b1.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFF48FB1}), SketchUi, null);
				b1.setBackground(SketchUiRD);
				b1.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*5);
				SketchUi.setStroke(d*0,0xFFFF5E00);
				b2.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFAB91}), SketchUi, null);
				b2.setBackground(SketchUiRD);
				b2.setClickable(true);
		}
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog1.dismiss();
				UnityAds.show(HomeActivity.this, "Rewarded_Android", new UnityAdsShowOptions(), showListener);
			}
		});
		b2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog1.dismiss();
				if (_button2text.equals("COLLECT")) {
					if (canCollect) {
						canCollect = false;
						map = new HashMap<>();
						transKey = history.push().getKey();
						map.put("type", "Daily Bonus");
						map.put("date", new SimpleDateFormat("dd-MM-yyyy hh:mm:ss ").format(cal.getTime()));
						map.put("coin", String.valueOf((long)(coi)));
						map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
						map.put("transKey", transKey);
						history.child(transKey).updateChildren(map);
						map.clear();
						m = new HashMap<>();
						m.put("balance", String.valueOf((long)(balance + coi)));
						m.put("total balance", String.valueOf((long)(totalBalance + coi)));
						All_Users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(m);
						m.clear();
						UnityAds.show(HomeActivity.this, "Interstitial_Android", new UnityAdsShowOptions(), showListener);
						SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(coi)).concat(" Add to wallet"));
						All_Users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(m);
						if (daily_cheak.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "").equals("")) {
							daily_cheak.edit().putString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "1").commit();
						}
						else {
							daily_cheak.edit().putString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), String.valueOf((long)(Double.parseDouble(daily_cheak.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "")) + 1))).commit();
						}
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Loading...");
						UnityAds.show(HomeActivity.this, "Rewarded_Android", new UnityAdsShowOptions(), showListener);
					}
				}
			}
		});
		dialog1.setCancelable(true);
		dialog1.show();
	}
	
	
	public void _exitdialog(final String _title, final String _message, final String _button1text, final String _button2text) {
		final AlertDialog technosahil = new AlertDialog.Builder(HomeActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.dialog2,null); 
		technosahil.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		technosahil.setView(inflate);
		TextView t1 = (TextView) inflate.findViewById(R.id.t1);
		
		TextView t2 = (TextView) inflate.findViewById(R.id.t2);
		
		TextView b1 = (TextView) inflate.findViewById(R.id.b1);
		
		TextView b2 = (TextView) inflate.findViewById(R.id.b2);
		
		LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
		
		androidx.cardview.widget.CardView cd = (androidx.cardview.widget.CardView) inflate.findViewById(R.id.cd);
		
		LinearLayout linear3 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
		cardview1.setCardBackgroundColor(Color.TRANSPARENT);
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		t2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_regular.ttf"), 0);
		b1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product.ttf"), 0);
		b2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product.ttf"), 0);
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*15);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				bg.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
				bg.setBackground(SketchUiRD);
				bg.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFFF44336,0xFFF44336};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*10);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				b1.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFCDD2}), SketchUi, null);
				b1.setBackground(SketchUiRD);
				b1.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF2196F3,0xFF2196F3};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*10);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				b2.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFBBDEFB}), SketchUi, null);
				b2.setBackground(SketchUiRD);
				b2.setClickable(true);
		}
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				technosahil.dismiss();
			}
		});
		b2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				technosahil.dismiss();
				finishAffinity();
			}
		});
		technosahil.setCancelable(true);
		technosahil.show();
	}
	
	
	public void _logout(final String _title, final String _message, final String _button1text, final String _button2text) {
		final AlertDialog technosahil = new AlertDialog.Builder(HomeActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.dialog1,null); 
		technosahil.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		technosahil.setView(inflate);
		TextView t1 = (TextView) inflate.findViewById(R.id.t1);
		
		TextView t2 = (TextView) inflate.findViewById(R.id.t2);
		
		TextView b1 = (TextView) inflate.findViewById(R.id.b1);
		
		TextView b2 = (TextView) inflate.findViewById(R.id.b2);
		
		LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
		
		LinearLayout linear3 = (LinearLayout) inflate.findViewById(R.id.linear3);
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		t2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_regular.ttf"), 0);
		b1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product.ttf"), 0);
		b2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product.ttf"), 0);
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF0F131E,0xFF0F131E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*15);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				bg.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
				bg.setBackground(SketchUiRD);
				bg.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFFEEEEEE,0xFFEEEEEE};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*10);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				b1.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), SketchUi, null);
				b1.setBackground(SketchUiRD);
				b1.setClickable(true);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF2196F3,0xFF2196F3};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadius(d*10);
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				b2.setElevation(d*0);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE3F2FD}), SketchUi, null);
				b2.setBackground(SketchUiRD);
				b2.setClickable(true);
		}
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				technosahil.dismiss();
			}
		});
		b2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				technosahil.dismiss();
				FirebaseAuth.getInstance().signOut();
				finishAffinity();
			}
		});
		technosahil.setCancelable(true);
		technosahil.show();
	}
	
	public class Viewpager1Adapter extends PagerAdapter {
		
		Context _context;
		ArrayList<HashMap<String, Object>> _data;
		
		public Viewpager1Adapter(Context _ctx, ArrayList<HashMap<String, Object>> _arr) {
			_context = _ctx;
			_data = _arr;
		}
		
		public Viewpager1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_context = getApplicationContext();
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public boolean isViewFromObject(View _view, Object _object) {
			return _view == _object;
		}
		
		@Override
		public void destroyItem(ViewGroup _container, int _position, Object _object) {
			_container.removeView((View) _object);
		}
		
		@Override
		public int getItemPosition(Object _object) {
			return super.getItemPosition(_object);
		}
		
		@Override
		public CharSequence getPageTitle(int pos) {
			// Use the Activity Event (onTabLayoutNewTabAdded) in order to use this method
			return "page " + String.valueOf(pos);
		}
		
		@Override
		public Object instantiateItem(ViewGroup _container,  final int _position) {
			View _view = LayoutInflater.from(_context).inflate(R.layout.banner_cus, _container, false);
			
			final RelativeLayout cp1 = _view.findViewById(R.id.cp1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			
			if (_data.get((int)_position).containsKey("adImage")) {
				android.graphics.drawable.GradientDrawable TechnoSahil = new android.graphics.drawable.GradientDrawable();
				TechnoSahil.setCornerRadius(40);
				TechnoSahil.setColor(Color.parseColor("#FF000000")); 
				imageview1.setBackground(TechnoSahil);
				imageview1.setClipToOutline(true);
				cp1.setVisibility(View.VISIBLE);
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("adImage").toString())).into(imageview1);
				cp1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent1.setAction(Intent.ACTION_VIEW);
						intent1.setData(Uri.parse(_data.get((int)_position).get("adURL").toString()));
						intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent1);
					}
				});
			}
			else {
				cp1.setVisibility(View.GONE);
			}
			
			_container.addView(_view);
			return _view;
		}
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.dot, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			if (position == _position) {
				linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
				linear1.setAlpha((float)(1.0d));
			}
			else {
				linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
				linear1.setAlpha((float)(0.5d));
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.leaderboard_cus, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview_rank = _view.findViewById(R.id.textview_rank);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final TextView textview_name = _view.findViewById(R.id.textview_name);
			final TextView textview_balance = _view.findViewById(R.id.textview_balance);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			cardview1.setCardBackgroundColor(Color.TRANSPARENT);
			{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					int clrs [] = {0xFF142342,0xFF2D4778};
					SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
					SketchUi.setCornerRadius(d*360);
					SketchUi.setStroke(d*0,0xFFFFFFFF);
					linear3.setElevation(d*7);
					android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF171E2E}), SketchUi, null);
					linear3.setBackground(SketchUiRD);
					linear3.setClickable(true);
			}
			if ((_position == 0) || ((_position == 1) || (_position == 2))) {
				linear1.setVisibility(View.GONE);
			}
			if (new DecimalFormat("0.00").format(_position / 3).contains(".00")) {
				circleimageview1.setImageResource(R.drawable.likefalse_9);
			}
			else {
				circleimageview1.setImageResource(R.drawable.user_ico);
			}
			textview_rank.setText(String.valueOf((long)(_position + 1)));
			if (_data.get((int)_position).containsKey("name")) {
				textview_name.setText(_data.get((int)_position).get("name").toString());
			}
			if (_data.get((int)_position).containsKey("total balance")) {
				textview_balance.setText(_data.get((int)_position).get("total balance").toString());
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}