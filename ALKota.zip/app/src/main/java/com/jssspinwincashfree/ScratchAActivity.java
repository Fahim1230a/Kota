package com.jssspinwincashfree;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.anupkumarpanwar.scratchview.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.unity3d.ads.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.jetbrains.kotlin.*;
import org.json.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdValue;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnPaidEventListener;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.OnAdMetadataChangedListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import android.widget.LinearLayout.LayoutParams;
import androidx.annotation.Nullable;

public class ScratchAActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> m = new HashMap<>();
	private double balance = 0;
	private String transKey = "";
	private HashMap<String, Object> map = new HashMap<>();
	private double coi = 0;
	private String color1 = "";
	private String color2 = "";
	private String ripple = "";
	private String strokeclr = "";
	private double stroke = 0;
	private double radius = 0;
	private double elevation = 0;
	private double number = 0;
	private double totalBalance = 0;
	
	private LinearLayout linear1;
	private LinearLayout top;
	private CardView cardview1;
	private LinearLayout linear4;
	private LinearLayout linear7;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout lin_coins;
	private ImageView imageview18;
	private TextView coin_balance;
	private LinearLayout linear3;
	private LinearLayout card;
	private ScratchView mScratchCard;
	private LinearLayout linear_wonspage;
	private TextView textview5;
	private LinearLayout linear9;
	private LinearLayout linear6;
	private TextView textview4;
	private LinearLayout linear8;
	
	private SharedPreferences sp_sc;
	private Calendar cal = Calendar.getInstance();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private Intent i_net = new Intent();
	private Intent i_s = new Intent();
	private Calendar c = Calendar.getInstance();
	private DatabaseReference All_Users = _firebase.getReference("All_Users");
	private ChildEventListener _All_Users_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference history = _firebase.getReference("history");
	private ChildEventListener _history_child_listener;
	private AlertDialog.Builder d;
	private SharedPreferences data;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.scratch_a);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		top = findViewById(R.id.top);
		cardview1 = findViewById(R.id.cardview1);
		linear4 = findViewById(R.id.linear4);
		linear7 = findViewById(R.id.linear7);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		lin_coins = findViewById(R.id.lin_coins);
		imageview18 = findViewById(R.id.imageview18);
		coin_balance = findViewById(R.id.coin_balance);
		linear3 = findViewById(R.id.linear3);
		card = findViewById(R.id.card);
		mScratchCard = findViewById(R.id.mScratchCard);
		linear_wonspage = findViewById(R.id.linear_wonspage);
		textview5 = findViewById(R.id.textview5);
		linear9 = findViewById(R.id.linear9);
		linear6 = findViewById(R.id.linear6);
		textview4 = findViewById(R.id.textview4);
		linear8 = findViewById(R.id.linear8);
		sp_sc = getSharedPreferences("sp_sc", Activity.MODE_PRIVATE);
		net = new RequestNetwork(this);
		auth = FirebaseAuth.getInstance();
		d = new AlertDialog.Builder(this);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				i_net.setClass(getApplicationContext(), ScratchAActivity.class);
				i_net.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i_net);
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				i_net.setClass(getApplicationContext(), NetworkActivity.class);
				i_net.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i_net);
			}
		};
		
		_All_Users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("balance")) {
						coin_balance.setText(_childValue.get("balance").toString().concat(" Coins"));
						balance = Double.parseDouble(_childValue.get("balance").toString());
					}
					if (_childValue.containsKey("total balance")) {
						totalBalance = Double.parseDouble(_childValue.get("total balance").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		All_Users.addChildEventListener(_All_Users_child_listener);
		
		_history_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		history.addChildEventListener(_history_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_telegramLoaderDialog(true);
		_NavStatusBarColor("#171E2E", "#0F131E");
		AdView linear9_adView = new AdView(ScratchAActivity.this);
		
		linear9_adView.setAdSize(AdSize.BANNER);
		        linear9_adView.setAdUnitId(data.getString("admobBanner", ""));
		        linear9.addView(linear9_adView);
		        
		        AdRequest linear9_req = new            AdRequest.Builder().build();
		   linear9_adView.loadAd(linear9_req);
		UnityAds.initialize(getApplicationContext(), data.getString("unityID", ""), false, new IUnityAdsInitializationListener() {
			@Override
			public void onInitializationComplete() {
				UnityAds.load("Interstitial_Android", loadListener);
				UnityAds.load("Rewarded_Android", loadListener);
			}
			@Override
			public void onInitializationFailed(UnityAds.UnityAdsInitializationError unityAdsInitializationError, String TechnoSahil) {
				 
			}
		});
		totalBalance = 0;
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF171E2E,0xFF171E2E};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadii(new float[]{0, 0, 0, 0, 14, 14, 14, 14});
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				top.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
				top.setBackground(SketchUiRD);
				top.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFFDE5C9A,0xFFBD6DEC};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadii(new float[]{360, 360, 360, 360, 360, 360, 360, 360});
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				lin_coins.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
				lin_coins.setBackground(SketchUiRD);
				lin_coins.setClickable(false);
		}
		{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				int clrs [] = {0xFF142342,0xFF2D4778};
				SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
				SketchUi.setCornerRadii(new float[]{360, 360, 360, 360, 360, 360, 360, 360});
				SketchUi.setStroke(d*0,0xFFFFFFFF);
				linear6.setElevation(d*7);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear6.setBackground(SketchUiRD);
				linear6.setClickable(true);
		}
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 0);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 1);
		linear6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFF00002E));
		card.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)35, 0xFFFFFFFF));
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			if (sp_sc.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "").equals("50")) {
				SketchwareUtil.showMessage(getApplicationContext(), "Already Completed 50");
				linear6.setVisibility(View.GONE);
			}
			else {
				ScratchView mScratchCardSahil = findViewById(R.id.mScratchCard);
				        mScratchCardSahil.setRevealListener(new ScratchView.IRevealListener() {
					            @Override
					            public void onRevealed(ScratchView mScratchCardSahil) {
						                
						
						linear6.setVisibility(View.VISIBLE);
						UnityAds.show(ScratchAActivity.this, "Rewarded_Android", new UnityAdsShowOptions(), showListener);
						
						            }
					
					            @Override
					            public void onRevealPercentChangedListener(ScratchView mScratchCardSahil, float percent) {
						                if (percent>=0.3d) {
							                    Log.d("Reveal Percentage", "onRevealPercentChangedListener: " + String.valueOf(percent));
							                }
						            }
					        });
			}
		}
		else {
			i_net.setClass(getApplicationContext(), NetworkActivity.class);
			i_net.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(i_net);
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	public void _RewardedAd() {
	}private IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
		@Override
		public void onUnityAdsAdLoaded(String placementId) {
			_telegramLoaderDialog(false);
		}
		@Override
		public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String TechnoSahil) {
			 
		}
	};
	private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
		@Override
		public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String TechnoSahil) {
			 
		}
		@Override
		public void onUnityAdsShowStart(String placementId) {
			 
		}
		@Override
		public void onUnityAdsShowClick(String placementId) {
			 
		}
		@Override
		public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
			if (state.equals(UnityAds.UnityAdsShowCompletionState.COMPLETED)) {
				UnityAds.load(placementId, loadListener);
				if (placementId.equals("Rewarded_Android")) {
					textview5.setText(String.valueOf((long)(SketchwareUtil.getRandom((int)(3), (int)(9)))));
					SketchwareUtil.showMessage(getApplicationContext(), "You Won ".concat(textview5.getText().toString().concat(" Coins ")));
					mScratchCard.setVisibility(View.GONE);
					m = new HashMap<>();
					m.put("balance", String.valueOf((long)(balance + Double.parseDouble(textview5.getText().toString()))));
					m.put("total balance", String.valueOf((long)(totalBalance + Double.parseDouble(textview5.getText().toString()))));
					All_Users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(m);
					m.clear();
					m = new HashMap<>();
					transKey = history.push().getKey();
					m.put("type", "Scratch Card ");
					m.put("coin", textview5.getText().toString());
					m.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					m.put("date", new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(c.getTime()));
					m.put("key", transKey);
					history.child(transKey).updateChildren(m);
					m.clear();
					SketchwareUtil.showMessage(getApplicationContext(), "You Won ".concat(textview5.getText().toString().concat(" Coins ")));
					if (sp_sc.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "").equals("")) {
						sp_sc.edit().putString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "1").commit();
					}
					else {
						sp_sc.edit().putString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), String.valueOf((long)(Double.parseDouble(sp_sc.getString(new SimpleDateFormat("ddMMyyyy").format(cal.getTime()), "")) + 1))).commit();
					}
				}
			} else {
				UnityAds.load(placementId, loadListener);
			}
		}
	};
	//Blocks are made By Techno Sahil
	{
	}
	
	
	public void _NavStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout background = (LinearLayout)coreprog.findViewById(R.id.background);
			
			LinearLayout layout_progress = (LinearLayout)coreprog.findViewById(R.id.layout_progress);
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#111D37")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
			RadialProgressView progress = new RadialProgressView(this);
			layout_progress.addView(progress);
		}
		else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}